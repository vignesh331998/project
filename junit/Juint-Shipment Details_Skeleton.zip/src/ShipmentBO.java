import java.text.SimpleDateFormat;
import java.util.*;

public class ShipmentBO {
	static SimpleDateFormat sdf ;
	static
	{
		sdf = new SimpleDateFormat("dd/MM/yyyy");
	}
	ShipmentDAO shipmentDAO = new ShipmentDAO();
	 public void updateArrivalDate(Integer id,String date,List<Shipment> shipmentList) 
	 							throws Exception
    {
	 	for(Shipment s : shipmentList)
	 	{
	 		if(s.getId() == id)
	 			s.setArrivalDate(sdf.parse(date));
	 	}	
	}
	
	public List<String> filterByArrivalDate(List<Shipment> shipmentList,Date date) 
								throws Exception
	{	 
		List<String> stringList = new ArrayList<String>();
		
		for(Shipment shipment : shipmentList)
		{
			if(shipment.getArrivalDate().before(date) || 
					shipment.getArrivalDate().equals(date))
			{
				stringList.add(shipment.getName());
			}
		}
		return stringList;
		 
	 }
}
