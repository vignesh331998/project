import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.List;
public class Main {
	static List<Shipment> shipmentList;
	static List<String> filteredList;
	static SimpleDateFormat sdf ;
    static
    {
    	shipmentList = ShipmentDAO.shipmentList;
    	sdf = new SimpleDateFormat("dd/MM/yyyy");
    }
    public static void main(String ags[])throws Exception{
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    	ShipmentBO shipmentDAO = new ShipmentBO();
    	System.out.println("Shipment details:");
    	System.out.println("Enter the date to filter the arraival date:");
    	
    	filteredList = shipmentDAO.filterByArrivalDate(shipmentList,sdf.parse(br.readLine()));
   	    System.out.println(String.format("%-15s%-25s%-15s%s", "Id","Name","Arrival Date","Weight"));
		for(String s:filteredList)
            	   System.out.println(s);
    		
    	System.out.println("Enter the number of updates");
        int n=Integer.parseInt(br.readLine());
        for(int j=0;j<n;j++)
        {
	        System.out.println("Enter the id and date "+(j+1)+" :");
	        String date=br.readLine();
	        String[] arr = date.split(",");
	        shipmentDAO.updateArrivalDate(Integer.parseInt(arr[0]),arr[1],shipmentList);
        }
        System.out.println("Updated successfully");
        System.out.println("After updation");
        for(Shipment shipment:shipmentList)
     	   System.out.println(String.format("%-15s%-25s%-15s%s",shipment.getId(),shipment.getName(),sdf.format(shipment.getArrivalDate()),shipment.getTotalWeight()));
	
    }
           
 }
