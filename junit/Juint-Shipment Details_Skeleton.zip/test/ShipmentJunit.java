public class ShipmentJunit {

	public void shipmentObjectCreation()
	{
		//fill code here.
	}
	
	public void testUpdateArrivalDate() 
	{
		//fill code here.
	}
	
	public void testFilterByArrivalDate() 
	{
		//fill code here.
	}
}

