import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
public class Main {
	public static void main(String[] args) throws IOException, ClassNotFoundException, SQLException, ParseException, InvalidPaymentException {
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
    	SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Invoice Details:");
		System.out.format("%-5s %-15s %-20s %-15s %-10s %s\n","ID","Customer Name","Payment Attempts","Total Amount","Balance","Status");		
		try {
		//fill the code
		InvoiceBO invoiceBO=new InvoiceBO();
		List<Invoice> listOfInvoices=invoiceBO.getAllInvoice();
		for(Invoice invoice:listOfInvoices)
		{
			System.out.format("%-5s %-15s %-20s %-15s %-10s %s\n",invoice.getId(),invoice.getCustomerName(),invoice.getPaymentAttempts(),invoice.getTotalAmount(),invoice.getBalance(),invoice.getStatus());
		}
		System.out.println("Enter the invoice id to pay :");
		Integer id = Integer.parseInt(buff.readLine());
		System.out.println("Enter the name :");
		String name = buff.readLine();		
		System.out.println("Enter the amount :");
		Double amount = Double.parseDouble(buff.readLine());
		System.out.println("Enter the card number :");
		String cardNo = buff.readLine();		
		System.out.println("Enter the cvv :");
		String cvv = (buff.readLine());
		System.out.println("Enter the card name :");
		String cardName = buff.readLine();
		CreditCardPayment creditCardPayment=new CreditCardPayment(name, amount, cardNo, cvv, cardName);
		Double totalAmount=creditCardPayment.calculateTotalAmount();
		// fill the code
		Double balanceAmount=0.0;
		System.out.printf("Total Amount to be paid is %.2f\n",totalAmount);
		//fill the code
		for(Invoice invoice:listOfInvoices)
		{
			if(invoice.getId()==id)
			{
				balanceAmount=invoice.getBalance()-amount;
			}
		}
		invoiceBO.updateInvoiceDetails(id, balanceAmount);
		System.out.printf("The balance amount is %.2f",balanceAmount);
		}
		catch(InvalidPaymentException ipe)
		{
			System.out.println(ipe);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}	
}
