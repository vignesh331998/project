public class InvalidPaymentException extends Exception {
	// fill the code
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public InvalidPaymentException(String message)
	{
		super(message);
	}
}
