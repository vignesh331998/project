import java.util.regex.Pattern;
public class CreditCardPayment  extends Payment// fill the code
{
	private String cardNumber;
	private String cvv;
	private String cardName;
	public CreditCardPayment() {
	}
	public CreditCardPayment(String name, Double amount, String cardNumber, String cvv, String cardName) {
		super(name, amount);
		this.cardNumber = cardNumber;
		this.cvv = cvv;
		this.cardName = cardName;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	@Override
	public Double calculateTotalAmount() throws InvalidPaymentException{ 
	if(!Pattern.matches("^[0-9]{16}$",cardNumber)||!Pattern.matches("^[0-9]{3}$",cvv))
	{
		throw new InvalidPaymentException("Invalid Card Details");
	}
	else
	{
		Double d=super.amount+(0.1*super.amount);
		return d;
	}
	}
}
