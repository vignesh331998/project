import java.sql.SQLException;
import java.util.List;
public class InvoiceBO {
	InvoiceDAO invoiceDAO=new InvoiceDAO();
	public List<Invoice> getAllInvoice() throws ClassNotFoundException, SQLException {
		//fill the code
		return invoiceDAO.getAllInvoices();
	}
	public void updateInvoiceDetails(int id,Double amount) throws ClassNotFoundException, SQLException {
		//fill the code
	 invoiceDAO.updateInvoiceDetails(id, amount);
	}
	
}

