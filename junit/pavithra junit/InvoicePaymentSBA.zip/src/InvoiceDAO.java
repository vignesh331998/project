import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
public class InvoiceDAO {
	public List<Invoice> getAllInvoices() throws ClassNotFoundException, SQLException{
		// fill the code
		Connection con=DbConnection.getConnection();
		List<Invoice> listOfInvoices = new ArrayList<>();
		try {
		Statement stmt=con.createStatement();  
		ResultSet resultSet=stmt.executeQuery("select * from invoice");  
			while (resultSet.next()) {
				listOfInvoices.add(new Invoice(resultSet.getInt("id"),resultSet.getString("customer_name"),resultSet.getInt("payment_attempts"),resultSet.getDouble("total_amount"),resultSet.getDouble("balance"),resultSet.getString("status")));
			}
		}catch(Exception e){ 
			con.close();		
		System.out.println(e);
		}
		return listOfInvoices;
		}  
	public void updateInvoiceDetails(Integer invoiceId, Double amount) throws ClassNotFoundException, SQLException{
		// fill the code
		Connection con=DbConnection.getConnection();
		Connection con1=DbConnection.getConnection();
		int count=0;
		try {
		Statement stmt=con.createStatement();
		ResultSet resultSet=stmt.executeQuery("select * from invoice where id="+invoiceId);
			while (resultSet.next()) {
				count=resultSet.getInt("payment_attempts");
			}
			count=count+1;
			Statement stmt1=con1.createStatement();
			stmt1.executeUpdate("update invoice set payment_attempts="+count+",balance="+amount+" where id="+invoiceId);
		}catch(Exception e){ 
			con.close();		
		System.out.println(e);
		}
		}  
	}
