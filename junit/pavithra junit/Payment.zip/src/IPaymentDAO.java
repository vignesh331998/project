import java.sql.SQLException;
import java.util.List;

public interface IPaymentDAO {

    //fill the code
	
public void insertPaymentDetails(List<Cheque> chequeList) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException;
	
	
}