import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

public class PaymentBO {

    public List<Cheque> getChequeList(String[] fileData) throws IOException, ClassNotFoundException, SQLException,InvalidPaymentException, InstantiationException, IllegalAccessException{        
    	//fill the code
    	List<Cheque> cheques = new ArrayList<Cheque>();
    	for(int i=0;i<fileData.length;i++){
    		String[] splitted = fileData[i].split(",");
    		if(Pattern.matches("^(INV)[0-9]{5}",splitted[2])){
    		cheques.add(new Cheque(Integer.parseInt(splitted[6]), splitted[7], splitted[8], new Payment(Integer.parseInt(splitted[0]),splitted[1],splitted[2],
    				Integer.parseInt(splitted[3]),Double.parseDouble(splitted[4]),splitted[5])));
    		} else{
    			throw new InvalidPaymentException("Invalid invoice number :"+splitted[2]+"\nUpdate correct invoice number in file");
    		}
    	}   	
    	PaymentDAO paymentDAO = new PaymentDAO();
    	paymentDAO.insertPaymentDetails(cheques);
    	return cheques;
	}	         
	          
    
	public String[] getFileDetails() throws IOException{
		  BufferedReader br1 = new BufferedReader(new FileReader("Payment.csv"));
		   //fill the code
		  String line;
		  int i=0;
		  int j=0;
		  while(br1.readLine()!=null){
			  i++;
		  }
		  String[] lines = new String[i];
		  BufferedReader br2 = new BufferedReader(new FileReader("Payment.csv"));
		  while((line = br2.readLine())!=null){
			  lines[j++] = line;
		  }
		  return lines;
	}
	

	
 }