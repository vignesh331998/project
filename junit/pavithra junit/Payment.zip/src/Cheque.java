
public class Cheque {

	Integer chequeId;
	String bankName;
	String chequeNumber;
	Payment payment;		
	
	public Cheque(Integer chequeId,String bankName, String chequeNumber, Payment payment) {
		this.chequeId=chequeId;
		this.bankName = bankName;
		this.chequeNumber = chequeNumber;
		this.payment = payment;
	}
	


	public Integer getChequeId() {
		return chequeId;
	}
	public void setChequeId(Integer chequeId) {
		this.chequeId = chequeId;
	}
	
	
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getChequeNumber() {
		return chequeNumber;
	}
	public void setChequeNumber(String chequeNumber) {
		this.chequeNumber = chequeNumber;
	}
	public Payment getPayment() {
		return payment;
	}
	public void setPayment(Payment payment) {
		this.payment = payment;
	}
	
	
}
