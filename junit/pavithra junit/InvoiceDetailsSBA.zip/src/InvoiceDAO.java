import java.util.List;
import java.util.ArrayList;
public class InvoiceDAO {
	public List<Invoice> loadInvoiceDetails() {
		List<Invoice> invoices = new ArrayList<Invoice>();
		
		invoices.add(new Invoice(101,"Ricky",5,38000.0,4000.0,"Pending"));
		invoices.add(new Invoice(102,"Jack",4,74000.0,21000.0,"Pending"));
		invoices.add(new Invoice(103,"James",6,85000.0,0.0,"Cleared"));
		invoices.add(new Invoice(104,"Peter",3,47000.0,8000.0,"Pending"));
		invoices.add(new Invoice(105,"Willium",8,68000.0,17000.0,"Pending"));
		invoices.add(new Invoice(106,"Johny",7,51000.0,0.0,"Cleared"));
		invoices.add(new Invoice(107,"John",6,85000.0,3000.0,"Pending"));
		invoices.add(new Invoice(108,"Parker",3,47000.0,8000.0,"Pending"));
		invoices.add(new Invoice(109,"Augestine",8,68000.0,17000.0,"Pending"));
		invoices.add(new Invoice(110,"David",3,85000.0,0.0,"Cleared"));
		
		return invoices;
	}
}