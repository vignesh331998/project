public class Invoice {
	private Integer id;
	private String customerName;
	private Integer paymentAttempts;
	private Double totalAmount;
	private Double balance;
	private String status;
	public Invoice() {}
	public Invoice(Integer id, String customerName, Integer paymentAttempts, Double totalAmount, Double balance, String status) {
		this.id = id;
		this.customerName = customerName;
		this.paymentAttempts = paymentAttempts;
		this.totalAmount = totalAmount;
		this.balance = balance;
		this.status = status;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Integer getPaymentAttempts() {
		return paymentAttempts;
	}
	public void setPaymentAttempts(Integer paymentAttempts) {
		this.paymentAttempts = paymentAttempts;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public boolean equals(Object obj) {
		Invoice invoice = (Invoice)obj;
		if(invoice.getId().equals(id) && invoice.getCustomerName().equals(customerName) && invoice.getTotalAmount().equals(totalAmount) && invoice.getBalance().equals(balance) && invoice.getStatus().equals(status))
			return true;
		return false;
	}
}