import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class PaymentDAO implements IPaymentDAO {    
      
	  public void insertPaymentDetails(List<Cheque> chequeList) throws InstantiationException, IllegalAccessException, ClassNotFoundException, SQLException {
	     //fill the code
		  Connection con = DBConnection.getConnection();
		  for(Cheque c : chequeList){
			  String sql2 = "insert into payment values(?,?,?,?,?,?)";
			  PreparedStatement prep2 = con.prepareStatement(sql2);
			  prep2.setInt(1,c.getPayment().getId());
			  prep2.setString(2, c.getPayment().getCustomerName());
			  prep2.setString(3, c.getPayment().getInvoiceNumber());
			  prep2.setInt(4,c.getPayment().getAttempt());
			  prep2.setDouble(5,c.getPayment().getAmount());
			  prep2.setString(6,c.getPayment().getStatus());
			  prep2.executeUpdate();
			  String sql1 = "insert into cheque values(?,?,?,?)";
			  PreparedStatement prep1 = con.prepareStatement(sql1);
			  prep1.setInt(1,c.getChequeId());
			  prep1.setString(2, c.getBankName());
			  prep1.setString(3, c.getChequeNumber());
			  prep1.setInt(4,c.getPayment().getId());
			  prep1.executeUpdate();
			 
		  }
    }

	  
	
  public  Payment getPaymentById(Integer paymentId) throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException{
       
	  //fill the code
	  Connection con = DBConnection.getConnection();
	  Statement stmt = con.createStatement();
	  ResultSet rs = stmt.executeQuery("select *from payment where id="+paymentId);
	  rs.next();
	  return new Payment(paymentId, rs.getString("customer_name"), rs.getString("invoice_number"), rs.getInt("attempt"), rs.getDouble("amount"), rs.getString("status"));
    }

}