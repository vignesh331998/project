import java.io.*;
import java.sql.SQLException;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class Main{
  public static void main(String args[]) throws IOException, ClassNotFoundException, SQLException, InvalidPaymentException{       
      
      PaymentBO paymentBO = new PaymentBO();	  
	 try{ 
	//fill the code 
	  List<Cheque> chequeList = null;
	  try {
		chequeList = paymentBO.getChequeList(paymentBO.getFileDetails());
	  } catch (InstantiationException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	  } catch (IllegalAccessException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	  }
	  System.out.println("Payment and Cheque details :");
	  System.out.format("%-2s %-7s %-9s %-4s %-8s %-9s %-8s %-8s\n","Id","Customer","InvoiceNo","Attempt","Amount","Status","Bank","ChequeNo");
       for(Cheque c : chequeList)
       {
          System.out.format("%-2s %-7s %-9s %-7s %-8s %-9s %-8s %-8s\n",c.getPayment().getId(),c.getPayment().getCustomerName(),c.getPayment().getInvoiceNumber(),c.getPayment().getAttempt(),c.getPayment().getAmount(),c.getPayment().getStatus(),c.getBankName(),c.getChequeNumber());
       }
	   
	  }
      catch(InvalidPaymentException e){
         //fill the code
    	  System.out.println(e.toString());
      }
  }
}