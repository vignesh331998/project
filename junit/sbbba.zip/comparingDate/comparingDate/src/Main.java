import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Main {

	public static void main(String[] args) throws NumberFormatException,
			IOException, ParseException {
		BufferedReader buf = new BufferedReader(
				new InputStreamReader(System.in));
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		System.out.println("Enter the number of shipments:");
		Integer n = Integer.parseInt(buf.readLine());
		Shipment[] shipments = new Shipment[n];
		String[] shipment;
		System.out.println("Enter the shipment details:");
		for (int i = 0; i < n; i++) {
			shipment = buf.readLine().split(",");
			shipments[i] = new Shipment(shipment[0], sdf.parse(shipment[1]),
					sdf.parse(shipment[2]));
		}
		System.out.println("Shipments that arrived on same day:");
		ShipmentBO shipmentBO = new ShipmentBO();

		for (String s : shipmentBO.getShipmentsOnSameDate(n, shipments)) {
			System.out.println(s);
		}
		System.out.println("Shipments that arrived on different day:");
		for (String s : shipmentBO.getShipmentsOnDiffDate(n, shipments)) {
			System.out.println(s);
		}
	}
}
