import java.util.Date;
public class Shipment {
	private String name;
	private Date departureDate;
	private Date arrivalDate;
	
	public Shipment(String name, Date departureDate, Date arrivalDate) {
		super();
		this.name = name;
		this.departureDate = departureDate;
		this.arrivalDate = arrivalDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
}
