import java.util.List;

public class ShipmentBO {

	public void updateShipment(int shipmentId, int shipmentStatusId,
			ShipmentDAO shipmentDAO) throws Exception {

		for (Shipment s : shipmentDAO.getAllShipment()) {
			if (s.getId() == shipmentId) {
				s.setShipmentStatus(shipmentDAO
						.getShipmentStatusByID(shipmentStatusId));
				return;
			} else
				throw new Exception(
						"Update failed. Please enter a valid shipment id and shipment status id");
		}
	}

	public void addShipment(Shipment shipment, int shipmentStatusId,
			ShipmentDAO shipmentDAO) throws Exception {

		shipment.setShipmentStatus(shipmentDAO
				.getShipmentStatusByID(shipmentStatusId));

		List<Shipment> shipments = shipmentDAO.getAllShipment();
		shipments.add(shipment);
	}

}
