
  import java.util.*;
public class Main {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		ShipmentBO shipmentBO = new ShipmentBO();
		Integer itemNo,weight,capacity;
		System.out.println("Enter the number of items :");
		itemNo = sc.nextInt();
		System.out.println("Enter the weight of each item :");
		weight = sc.nextInt();
		System.out.println("Enter the capacity of a container :");
		capacity = sc.nextInt();
		
		int noOfShippedItems = shipmentBO.findShippedItemCount(itemNo, weight, capacity);
		int noOfLeftOutItems = shipmentBO.findLeftOutCount(itemNo, noOfShippedItems);
		System.out.println("Number of items can be shipped through a container : "+noOfShippedItems);
		System.out.println("Number of items left out : "+noOfLeftOutItems);
		sc.close();
	}
}