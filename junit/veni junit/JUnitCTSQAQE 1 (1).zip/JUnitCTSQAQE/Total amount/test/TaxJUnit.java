import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class TaxJUnit {
	TaxBO taxBO;
	@Before
	public void createObjectForTaxBO() {
		taxBO = new TaxBO();
	}
	@Test
	public void testTaxes() {
		assertEquals(taxBO.calculateNetAmount(1, 1000),1050,0);
		assertEquals(taxBO.calculateNetAmount(1, 0),0,0);
		assertEquals(taxBO.calculateNetAmount(1, 40),42,0);
		
		assertEquals(taxBO.calculateNetAmount(2, 1000),1030,0);
		assertEquals(taxBO.calculateNetAmount(2, 0),0,0);
		assertEquals(taxBO.calculateNetAmount(2, 40),41.2,0);
		
		
		assertEquals(taxBO.calculateNetAmount(0, 1000),-1,0);
		assertEquals(taxBO.calculateNetAmount(3, 0),-1,0);
		assertEquals(taxBO.calculateNetAmount(-2, 40),-1,0);
		assertEquals(taxBO.calculateNetAmount(12, 40),-1,0);
	}
}