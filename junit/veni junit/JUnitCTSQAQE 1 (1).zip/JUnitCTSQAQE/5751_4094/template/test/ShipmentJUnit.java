import static org.junit.Assert.assertThat;

import java.sql.Date;
import java.util.Arrays;

import org.junit.Test;

public class ShipmentJUnit {

	@Test
	public void testComputeTotalProfit() {
		//fill the code
	}
}
