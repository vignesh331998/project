import org.junit.*;
import java.util.*;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.hamcrest.CoreMatchers.*;

public class JunitCheck {
DateFormatBO dfbo; 
@Before
	public void createObject()
	{
	dfbo = new DateFormatBO();
	}
@Test
	public void testDateFormat()
	{
		List<String> userList = new ArrayList<String>();
		List<String> dates = new ArrayList<String>();
		userList.add("01/01-2011");
		userList.add("01/02/2011");
		dfbo.convertToCorrectDateFormat(dates, userList);
		
		assertThat(dates, containsInAnyOrder("01-01-2011","01-02-2011"));
	}
	
}
