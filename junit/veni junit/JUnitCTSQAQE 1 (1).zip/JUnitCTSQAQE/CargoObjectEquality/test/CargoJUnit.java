import static org.junit.Assert.*;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.junit.Before;
import org.junit.Test;

public class CargoJUnit {
	Cargo cargo;
	CargoBO cargobo;
	
	@Before
	public void createObjectForCargo() {
		cargobo = new CargoBO();
	}
	@Test
	public void testCargoDetails() {
//		String name = "cargoname";
//		String desc = "cargodesc";
//		double length=300;
//		double width=4225;
		cargo = cargobo.cargoDetails("Cars","Lamborghini Veneno",300,225);
		assertTrue(EqualsBuilder.reflectionEquals(new Cargo("Cars","Lamborghini Veneno",300,225),cargo));
	}
}