import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	private ShipmentBO shipmentbo;
	@Test
	public void testEvaluateGrade_invalidInput(){
		
		assertEquals("Invalid Input",shipmentbo.evaluateGrade(-1, -10));
	}
	
	@Test
	public void testEvaluateGrade_gradeA(){
		assertEquals("A",shipmentbo.evaluateGrade(170, 1600));
	}
 
	@Test
	public void testEvaluateGrade_gradeB(){
		assertEquals("B",shipmentbo.evaluateGrade(150, 1500));
	}
 
	@Test
	public void testEvaluateGrade_gradeC(){
		assertEquals("C",shipmentbo.evaluateGrade(125, 1200));
	}
 
	@Test
	public void testEvaluateGrade_gradeD(){
		assertEquals("D",shipmentbo.evaluateGrade(100, 1000));
	}
 
	@Test
	public void testEvaluateGrade_gradeE(){
		assertEquals("E",shipmentbo.evaluateGrade(75, 700));
		assertEquals("E",shipmentbo.evaluateGrade(0, 0));
		assertEquals("E",shipmentbo.evaluateGrade(0, 10));
		assertEquals("E",shipmentbo.evaluateGrade(10, 0));
	}
	
	@Before
	public void setUp(){
		shipmentbo = new ShipmentBO();
	}
	
}
