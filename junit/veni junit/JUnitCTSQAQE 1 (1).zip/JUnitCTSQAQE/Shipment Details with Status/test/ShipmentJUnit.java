import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasProperty;


public class ShipmentJUnit {
	private ShipmentBO shipmentBO;
	@Before
	public void setUp(){
		shipmentBO = new ShipmentBO();
	}
	@Test
	public void testGetShipmentDetailsByStatus(){
		Shipment[] shipment = new Shipment[3];
		for(int i=0;i<3;i++){
			Shipment sh = new Shipment();
			sh.setName("sh"+(i+1));
			sh.setArrivalDate(new Date("11/12/2017"));
			sh.setDepartureDate(new Date("11/12/2017"));
			ShipmentStatus ss = new ShipmentStatus();
			ss.setCode(String.valueOf(i+1));
			ss.setName("status"+(i+1));
			sh.setShipmentStatus(ss);
			shipment[i] =sh; 
		}
		List<Shipment> ls = shipmentBO.getShipmentDetailsByStatus("status2", shipment);
//		assertThat(ls,containsInAnyOrder(hasProperty("name"),equalTo("sh2")));
		assertThat(ls,containsInAnyOrder(ls,containsInAnyOrder(hasProperty("name"),equalTo("sh2"))));
	}
	}
