import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ShipmentJunit {
	
	ShipmentBO shipmentBO;
	
	@Before
	public void createObjectForShipmentBO () {
		shipmentBO = new ShipmentBO();
	}
	 
	@Test
	public void testPriority() {
		//with in 1 days
		assertEquals(30.00, shipmentBO.findRate(10.00, "priority", 1),0);
		assertEquals(120, shipmentBO.findRate(40.00, "priority", 1),0);
		
		//with in 2 days
		assertEquals(20.00, shipmentBO.findRate(10.00, "priority", 2),0);
		assertEquals(21, shipmentBO.findRate(10.50, "priority", 2),0);
		assertEquals(400, shipmentBO.findRate(200.0, "priority", 2),0);
		
		//more than 2 days
		assertEquals(15.00, shipmentBO.findRate(10.00, "priority", 3),0);
		assertEquals(15, shipmentBO.findRate(10.00, "priority", 3),0);
		assertEquals(150, shipmentBO.findRate(100.00, "priority", 10),0);
		assertEquals(300, shipmentBO.findRate(200.00, "priority", 0),0);
		assertEquals(150, shipmentBO.findRate(100.00, "priority", 15),0);
	}
	
	@Test
	public void testNormal() {
		//Nrmal
		assertEquals(10, shipmentBO.findRate(10.00, "Normal"),0);
		assertEquals(50, shipmentBO.findRate(50.00, "Normal"),0);
		assertEquals(0, shipmentBO.findRate(0.0, "Normal"),0);
		assertEquals(500, shipmentBO.findRate(500.0, "Normal"),0);
	}
	
}
