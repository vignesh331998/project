import org.junit.*;

import java.util.*;

import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.MatcherAssert.assertThat;
public class PortJUnit {
	PortBO portBO ;
	
	@Before
	public void createObjectForPort()
	{
		portBO = new PortBO();
	}
	
	@Test
	public void testPortDetails()
	{	
		List<Port> l = new ArrayList<Port>();
		l.add(new Port(1,"Chennai Port","Chennai"));
		l.add(new Port(2,"Mumbai Port","Mumbai"));
		l.add(new Port(3,"Kolkata Port","Kolkata"));
		
		portBO.addElementAtSpecfiedPosition(l, 2, "4,'Pandichery Port','Pandichery'");
		
		assertThat(l,hasSize(4));
	}
}
