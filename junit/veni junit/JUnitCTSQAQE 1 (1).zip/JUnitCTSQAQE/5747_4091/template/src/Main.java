import java.io.*;
import java.util.*;

public class Main {
	public static void main(String args[]) throws Exception {
		int n, i;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		n = Integer.parseInt(br.readLine());
		List<Integer> userId = new ArrayList<Integer>();
		Set<Integer> repeat = new HashSet<Integer>();
		for (i = 0; i < n; i++)
			userId.add(Integer.parseInt(br.readLine()));
		Collections.sort(userId);
		repeat = new CustomerBO().findDuplicateCustomerId(n, userId);
		System.out.println("Duplicate records :");
		for (Integer id : repeat)
			System.out.println(id);
	}
}