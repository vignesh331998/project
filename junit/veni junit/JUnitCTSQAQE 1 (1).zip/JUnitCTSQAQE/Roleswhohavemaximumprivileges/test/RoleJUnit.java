import static org.junit.Assert.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.junit.*;
public class RoleJUnit {
	private RoleBO roleBO;
	@Before
	public void objectCeration()
	{
		roleBO = new RoleBO();
	}
	@Test
	public void test_findRoleWithMaxPrivilege()
	{

		Role[] roles=new Role[3];
		
		Role role1 = new Role("role1",new Privilege[]{new Privilege("role1privilege1"),new Privilege("role1privilege2")});
		Role role2 = new Role("role2",new Privilege[]{new Privilege("role2privilege1"),new Privilege("role2privilege2"),new Privilege("role2privilege3")});
		Role role3 = new Role("role3",new Privilege[]{new Privilege("role3privilege1"),new Privilege("role3privilege2"),new Privilege("role3privilege3")});
		roles[0]=role1;
		roles[1]=role2;
		roles[2]=role3;
		
		Role[] expected = new Role[2];
		expected[0] = role2;
		expected[1] = role3;
		assertArrayEquals(expected, roleBO.findRoleWithMaxPrivilege(roles));
		
		
		Role[] roles1=new Role[3];
		
		Role role4 = new Role("role1",new Privilege[]{new Privilege("role1privilege1"),new Privilege("role1privilege2")});
		Role role5 = new Role("role2",new Privilege[]{new Privilege("role2privilege1"),new Privilege("role2privilege2"),new Privilege("role2privilege3")});
		Role role6 = new Role("role3",new Privilege[]{new Privilege("role3privilege1"),new Privilege("role3privilege2")});
		roles1[0]=role4;
		roles1[1]=role5;
		roles1[2]=role6;
		
		Role[] expected1 = new Role[1];
		expected1[0] = role2;
		
		assertArrayEquals(expected1, roleBO.findRoleWithMaxPrivilege(roles1));
	}
	
	
}


