import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	double delta = 0.01;
	ShipmentBO shipment;

	@Before
	public void setup() {
		shipment = new ShipmentBO();
	}

	@Test
	public void testCalculateAverage() {
		//fill the code
	}
}
