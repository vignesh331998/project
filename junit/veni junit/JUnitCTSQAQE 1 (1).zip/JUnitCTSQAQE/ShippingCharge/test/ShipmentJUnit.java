import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	ShipmentBO shipmentBo;
	double delta = 0;

	@Before
	public void setup() {
		shipmentBo = new ShipmentBO();
	}

	@Test
	public void testEvaluateShippingCharge_forRoad() {
		assertEquals(10, shipmentBo.evaluateShippingCharge(100, 200, "Road"),0);
		assertEquals(12, shipmentBo.evaluateShippingCharge(400, 100, "road"),0);
		assertEquals(36, shipmentBo.evaluateShippingCharge(600, 600, "rOAd"),0);
	}

	@Test
	public void testEvaluateShippingCharge_forSea() {
		assertEquals(8.16, shipmentBo.evaluateShippingCharge(100, 100, "Sea"),0);
		assertEquals(32.64, shipmentBo.evaluateShippingCharge(100, 500, "seA"),0);
		assertEquals(32.64, shipmentBo.evaluateShippingCharge(100, 500, "sea"),0);

	}

	@Test
	public void testEvaluateShippingCharge_forAir() {
		assertEquals(322, shipmentBo.evaluateShippingCharge(100, 200, "Air"),0);
		assertEquals(352, shipmentBo.evaluateShippingCharge(600, 400, "air"),0);
		assertEquals(352, shipmentBo.evaluateShippingCharge(100, 500, "aIR"),0);

	}
}
