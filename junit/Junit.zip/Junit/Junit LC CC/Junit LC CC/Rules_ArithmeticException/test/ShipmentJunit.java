 import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class ShipmentJunit {
	ShipmentBO shipmentBO;
	double delta = 0.0;
	
	
	@Before
	public void init() {
		shipmentBO = new ShipmentBO();
	}
	
	@Test 
	public void testCalculatAverageWithoutZero() {
		assertEquals(20, shipmentBO.calculateAveragePrice(100, 5), delta);
	}
	
	@Rule
	    public ExpectedException thrown = ExpectedException.none();
	
	@Test
	public void testCalculateAverageWithZero() {
		thrown.expect(ArithmeticException.class);
        thrown.expectMessage("/ by zero");		
        assertEquals(0, shipmentBO.calculateAveragePrice(80, 0), delta);
	}
	
	@After
	public void destroy() {
		shipmentBO = null;
	}
}