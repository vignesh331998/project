import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	
	ShipmentBO shipmentBO;
		
	@Before
	public void setUp()
	{
		shipmentBO = new ShipmentBO();
	}
	
	@Test
	public void testFindOneModes() {

		String[] ports = {"101|Saswad|0|1|0","102|Pune|1|1|1","103|Shimla|1|0|1","104|Chennai|1|1|0","105|Leh|0|0|1", "106|Ladakh|1|0|0","107|Delhi|0|1|1"};
		String [] output = {"Saswad", "Leh", "Ladakh", null, null, null, null};
		assertArrayEquals(output, shipmentBO.findOneModes(7, ports));
	}
	
	@Test
	public void testFindMultipleModes() {

		String[] ports = {"101|Saswad|0|1|0","102|Pune|1|1|1","103|Shimla|1|0|1","104|Chennai|1|1|0","105|Leh|0|0|1","106|Ladakh|1|0|0","107|Delhi|0|1|1"};
		String [] output = {"Pune", "Shimla", "Chennai", "Delhi", null, null, null };
		assertArrayEquals(output, shipmentBO.findMultipleModes(7, ports));
	}
	
	
	}
