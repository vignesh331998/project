import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TaxJUnit {
	TaxBO taxBO;
	double delta = 0.0;
	@Before
	public void createObjectForTaxBO() {
		taxBO = new TaxBO();
	}
	@Test
	public void testTaxes() {
		assertEquals(5250,taxBO.calculateNetAmount(1, 5000),delta);
		assertEquals(6180,taxBO.calculateNetAmount(2, 6000),delta);
		assertEquals(4830.525,taxBO.calculateNetAmount(1, 4600.50),delta);
		assertEquals(6736.4575,taxBO.calculateNetAmount(2, 6540.25),delta);
	}
}