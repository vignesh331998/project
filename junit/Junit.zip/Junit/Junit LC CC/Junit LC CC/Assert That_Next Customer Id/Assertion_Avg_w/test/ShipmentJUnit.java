import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	double delta = 0.01;
	ShipmentBO shipment;

	@Before
	public void setup() {
		shipment = new ShipmentBO();
	}

	@Test
	public void testCalculateAverage() throws NoSuchMethodException, SecurityException {
		
		assertNotNull(shipment);
		assertEquals(40, shipment.calculateAverage(10, 50, 5, 20),delta);
		assertEquals(0, shipment.calculateAverage(0, 0, 0, 0),delta);
		
	}
	
	@After
	public void tearDown()
	{
		shipment = null;
	}
}
