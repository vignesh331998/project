import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.*;

import static org.hamcrest.Matchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
public class CustomerJunit {
	
	CustomerBO customerBO;
	ArrayList<Integer> customerid; 
	@Before
	public void init() {
		customerBO = new CustomerBO();
		customerid = new ArrayList<Integer>();
	}
	
	@Test
	public void testDuplicateCustomerId() {
		customerid.add(102);
		customerid.add(104);
		customerid.add(109);
		customerid.add(102);
		customerid.add(109);
	    HashSet<Integer> duplicate = customerBO.findDuplicateCustomerId(5, customerid);
	    assertThat(duplicate,containsInAnyOrder(109, 102));
	}
	
	@After
	public void destroy() {
		customerBO = null;
	}
}
