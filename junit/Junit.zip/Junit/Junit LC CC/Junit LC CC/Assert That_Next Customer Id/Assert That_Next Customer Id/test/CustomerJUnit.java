import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

public class CustomerJUnit {
	CustomerBO customer;

	@Before
	public void setUp() {
		customer = new CustomerBO();
	}

	@Test
	public void testFindNextCustomerId() {
		Integer[] customerid = new Integer[8];
		customerid[0]=5;
		customerid[1]=4;
		customerid[2]=3;
		customerid[3]=2;
		customerid[4]=7;
		customerid[5]=8;
		customerid[6]=6;
		customerid[7]=1;
		assertThat(customer.findNextCustomerId(8, customerid),is(8));
		Integer[] customerid1 = new Integer[10];
		customerid1[0]=5;
		customerid1[1]=4;
		customerid1[2]=3;
		customerid1[3]=2;
		customerid1[4]=7;
		customerid1[5]=8;
		customerid1[6]=6;
		customerid1[7]=9;
		customerid1[8]=10;
		customerid1[9]=1;
		assertThat(customer.findNextCustomerId(10, customerid1),is(10));
	}
}
