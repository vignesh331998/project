import org.junit.*;
import java.util.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.MatcherAssert.assertThat;
public class PortJUnit {
	
	PortBO portbo;
	List <Port> ports;
	@Before
	public void createObjectForPort()
	{
		ports = new ArrayList<Port>();
		ports.add(new Port(1, "Lonavla", "Pune"));
		ports.add(new Port(2, "Mulund", "Mumbai"));
		ports.add(new Port(3, "Andheri", "Mumbai"));
		ports.add(new Port(4, "Gurgaon", "Delhi"));
		portbo = new PortBO();
	}
	
	@Test
	public void testPortDetails()
	{	
		portbo.addElementAtSpecfiedPosition(ports, 5, "5,Poladpur,Patna");	
		assertThat(ports,hasSize(5));
		portbo.addElementAtSpecfiedPosition(ports, 6, "6,Rome,Romania");	
		assertThat(ports,hasSize(6));
	}
}
