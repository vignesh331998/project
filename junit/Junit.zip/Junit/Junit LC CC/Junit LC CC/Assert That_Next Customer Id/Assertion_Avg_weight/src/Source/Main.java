package Source;
import java.lang.reflect.Method;
import java.util.Scanner;

public class Main {
	public static void main(String args[]) throws NoSuchMethodException, SecurityException {
	
		Method calculateAverageMethod = ShipmentBO.class.getMethod("calculateAverage");
		System.out.print(calculateAverageMethod.getName());
		
	}

}
