import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class ShipmentJunit {
	
	ShipmentBO shipmentBO;
	
	@Before
	public void init() {
		shipmentBO = new ShipmentBO();
	}
	
	@Test
	public void testDeliveredOnTime() throws ParseException {
	
		assertEquals("Delivered on time", shipmentBO.findDeliveryType("2018-04-23", "2018-04-23"));
	}
	
	@Test
	public void testDeliveredOnDelay() throws ParseException {
		
		assertEquals("Delayed", shipmentBO.findDeliveryType("2018-04-22", "2018-04-23"));
	}
	
	@Test
	public void testDeliveredInAdvance() throws ParseException {
		
		assertEquals("Delivered in advance", shipmentBO.findDeliveryType("2018-04-23", "2018-04-22"));
	}
	

	public void destroy() {
		shipmentBO = null;
	}
}
