import java.text.ParseException;

import static org.junit.Assert.*;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.Before;
import org.junit.Test;

public class DateJUnit {
	DateValidationBO dateValidationBO;
	@Before
	public void createObjectForCustomerBO() {
		dateValidationBO = new DateValidationBO();
	}
	@Test
	public void testFindValidDate() throws ParseException {
		assertThat(dateValidationBO.findValidDate("11/25/2017"), DateChecker.checkDate("25/11/2017"));
	}
}
class DateChecker {
    public static Matcher<String> checkDate(final String pattern) 
    {
        return new TypeSafeMatcher<String>() {
            
            @Override
            public void describeTo(final Description description) {
            description.appendText("expected result from check date: ").appendValue(pattern);
            }
            
            @Override
            public boolean matchesSafely(final String date) {
                return pattern.equals(date);
                
            }
            
            @Override
            public void describeMismatchSafely(final String date, final Description mismatchDescription) {
            String str = mismatchDescription.toString();
            mismatchDescription.appendText("was ").appendValue(date);
            }
        };
    }
}