import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Main {

	public static void main(String args[]) throws IOException, ParseException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String name, shipmentStaus, code, description, status;
		Date arrivalDate, departureDate;
		Integer numberOfShipment, i;
		SimpleDateFormat formatter = new SimpleDateFormat("dd-mm-yyyy");

		ShipmentBO shipmentBOIns = new ShipmentBO();

		System.out.println("Enter the number of shipment status");
		int n = Integer.parseInt(br.readLine());

		ShipmentStatus shipmentStatusIns[] = new ShipmentStatus[n];

		for (i = 0; i < n; i++) {
			System.out.println("Enter the shipment status " + (i + 1)
					+ " details");
			String shipmentStatus = br.readLine();
			String shipmentStatusArray[] = shipmentStatus.split(",");
			// System.out.println("code  "+shipmentStatusArray[0]);
			// System.out.println("name "+shipmentStatusArray[1]);
			shipmentStatusIns[i] = new ShipmentStatus();
			shipmentStatusIns[i].setCode(shipmentStatusArray[0]);

			shipmentStatusIns[i].setName(shipmentStatusArray[1]);

		}
		System.out.println("Enter the number of shipments");

		numberOfShipment = Integer.parseInt(br.readLine());
		Shipment shipment[] = new Shipment[numberOfShipment];
		ShipmentStatus shipmentStatusTemp = null;

		for (i = 0; i < numberOfShipment; i++) {
			shipment[i] = new Shipment();

			System.out.println("Enter the shipment " + (i + 1) + " details");
			String shipmentString = br.readLine();
			String shipmentString1[] = shipmentString.split(",");

			// System.out.println("code1 "+" "+shipmentStatusIns[i].getCode());

			shipmentStatusTemp = shipmentBOIns.findShipmentStatusByCode(
					shipmentString1[3], shipmentStatusIns);

			shipment[i].setName(shipmentString1[0]);
			shipment[i].setArrivalDate(formatter.parse(shipmentString1[1]));
			shipment[i].setDepartureDate(formatter.parse(shipmentString1[2]));

			code = shipmentString1[3];
			ShipmentStatus s = null;
			s = shipmentBOIns.findShipmentStatusByCode(code, shipmentStatusIns);

			shipment[i].setShipmentStatus(s);
		}
		System.out.println("Enter the shipment status to be searched");
		status = br.readLine();
		List<Shipment> shipments = shipmentBOIns
				.getShipmentDetailsByStatus(status, shipment);
		for (Shipment ship : shipments) {
			System.out.println(ship.toString());
		}
	}
}