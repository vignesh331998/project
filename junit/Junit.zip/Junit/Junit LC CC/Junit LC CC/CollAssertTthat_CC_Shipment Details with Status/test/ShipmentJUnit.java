import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasProperty;
import static org.junit.Assert.assertThat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	ShipmentBO shipment;

	@Before
	public void setUp() {
		shipment = new ShipmentBO();
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testGetShipmentDetailsByStatus() throws ParseException {
		Shipment s1 = new Shipment();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-mm-yyyy");
		s1.setName("Houston");
		s1.setArrivalDate(formatter.parse("12-05-2017"));
		s1.setDepartureDate(formatter.parse("22-05-2017"));
		ShipmentStatus ss1 = new ShipmentStatus();
		ss1.setCode("112");
		ss1.setName("Delayed");
		s1.setShipmentStatus(ss1);

		Shipment s2 = new Shipment();
		s2.setName("Boston");
		s2.setArrivalDate(formatter.parse("12-05-2017"));
		s2.setDepartureDate(formatter.parse("22-05-2017"));
		ShipmentStatus ss2 = new ShipmentStatus();
		ss2.setCode("114");
		ss2.setName("Delayed");
		s2.setShipmentStatus(ss2);
		Shipment[] shipments = { s1, s2 };

		List<Shipment> finalShipments = shipment.getShipmentDetailsByStatus(
				"Delayed", shipments);

		assertThat(
				finalShipments,
				containsInAnyOrder(hasProperty("name", is("Houston")),
						hasProperty("name", is("Boston"))));
		assertThat(finalShipments.get(0).getShipmentStatus(),
				hasProperty("code", is("112")));
		assertThat(finalShipments.get(1).getShipmentStatus(),
				hasProperty("code", is("114")));
	}
}
