public class UserBO {
    
        void validatePassword(User user) throws WeakPasswordException
    {
        int size,i;
        boolean digit=false, specialCase=false;
        size = user.getPassword().length();
        
        for(i=0;i<size;i++)
        {
            if(user.getPassword().charAt(i) > '0' && user.getPassword().charAt(i) < '9')
            {
                digit = true;
            }
            if(user.getPassword().charAt(i) == '!' ||user.getPassword().charAt(i) == '@' ||user.getPassword().charAt(i) == '#' ||user.getPassword().charAt(i) == '$'|| user.getPassword().charAt(i) == '%' )
            {
                specialCase = true;
            }
        }
            if(!(size >= 8 && digit && specialCase))
                throw new WeakPasswordException("Password is weak");
            
    }
     
}