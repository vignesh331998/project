 import java.io.*;
public class Main {

    public static void main(String[] args) throws Exception {
        String userName,password,address;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Enter user name :");
        userName = br.readLine();
        System.out.println("Enter password :");
        password = br.readLine();
        System.out.println("Enter address :");
        address = br.readLine();
        User user = new User(userName, password, address);
        try
        {
            new UserBO().validatePassword(user);
            System.out.println("Password is strong");
        }
        catch(WeakPasswordException e)
        {
            System.out.println(e);
        }
    }
    
}