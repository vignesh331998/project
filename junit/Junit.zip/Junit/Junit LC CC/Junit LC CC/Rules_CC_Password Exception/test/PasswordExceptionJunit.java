import static org.junit.Assert.*;

import org.junit.*;
public class PasswordExceptionJunit {
	
	UserBO userBO;
	
	@Before
	public void userObjectCreation() {
		userBO = new UserBO();
	}
	
	@Test
	public void testPasswordException() throws WeakPasswordException {
		User user1 = new User("Ram","Ganesh@123","Saswad");
		userBO.validatePassword(user1);
		assertEquals("Ram", user1.getUserName());
		assertEquals("Ganesh@123", user1.getPassword());
		assertEquals("Saswad", user1.getAddress());
		
	    try {
			User user2 = new User("Raj","Ganesh123","Pune");
			userBO.validatePassword(user2);
	        fail();
	    }
	    catch(WeakPasswordException e) {
	        assertEquals(e.toString(),"WeakPasswordException: Password is weak");
	    }
	    
	    try {
			User user3 = new User("Rao","Ganeshaa@","Nashik");
			userBO.validatePassword(user3);
	        fail();
	    }
	    catch(WeakPasswordException e) {
	        assertEquals(e.toString(),"WeakPasswordException: Password is weak");
	    }
		
	    try {
			User user4 = new User("Rao","Ganes1@","Delhi");
			userBO.validatePassword(user4);
	        fail();
	    }
	    catch(WeakPasswordException e) {
	        assertEquals(e.toString(),"WeakPasswordException: Password is weak");
	    }

	}
	
}
