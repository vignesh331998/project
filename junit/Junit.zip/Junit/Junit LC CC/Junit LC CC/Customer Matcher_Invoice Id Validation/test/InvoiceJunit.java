import static org.junit.Assert.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.hamcrest.Description;
import org.hamcrest.Factory;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class InvoiceJunit {
	InvoiceBO invoiceBO;
	@Before
	public void init() {
		invoiceBO = new InvoiceBO();
	}
	@Test
	public void testGeneratedInvoiceId() {
	      assertThat(invoiceBO.generateInvoiceId("CU1"), CheckInvoiceId.isValidInvoiceId());
	        assertThat(invoiceBO.generateInvoiceId("CY231"),CheckInvoiceId.isValidInvoiceId());
	        assertThat(invoiceBO.generateInvoiceId("AT12"),CheckInvoiceId.isValidInvoiceId());
	        assertThat(invoiceBO.generateInvoiceId("AT1234"),CheckInvoiceId.isValidInvoiceId());
	}
	@After
	public void destroy() {
		invoiceBO = null;
	}
}

class CheckInvoiceId extends TypeSafeMatcher<String>{

	@Override
	public void describeTo(Description desc) {
		desc.appendText("Invalid Format");
	}

	@Override
	protected boolean matchesSafely(String invoiceId) {
	       String pattern = "(C|A){1}+(UR|GT|MY)\\d{5}$";
	        Pattern pat = Pattern.compile(pattern);
	        Matcher match = pat.matcher(invoiceId);
	        if(match.matches())
	            return true;
	        return false;
	}

    @Factory
    public static <T> org.hamcrest.Matcher<String> isValidInvoiceId() {
           return new CheckInvoiceId();
    }
}

