
import org.junit.*;
import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import java.util.*;

public class Junit {

	ShipmentEntityBO  shipmentEntityBO;
	List <ShipmentEntity> shipmentEntityList;
	@Before
	public void createObjectForShipmentEntity()
	{
	    shipmentEntityBO = new ShipmentEntityBO();
	    shipmentEntityList = new ArrayList<>();
				
	}
	
	@Test
	public void testListofShipmentEntity()
	{
		 shipmentEntityBO.addShipmentEntityToList(shipmentEntityList, "101,Adam,5987413568,8500000,New York");
		    shipmentEntityBO.addShipmentEntityToList(shipmentEntityList, "188771,louis,5082509106,74431,Garhbeta");
		    shipmentEntityBO.addShipmentEntityToList(shipmentEntityList, "103,Mike Hastings,3514537165,540000300,Sydney");
		    assertThat(shipmentEntityList, containsInAnyOrder(
		        new ShipmentEntity(188771, "louis", "5082509106", Long.valueOf("74431"), "Garhbeta"),
		        new ShipmentEntity(103, "Mike Hastings", "3514537165", Long.valueOf("540000300"), "Sydney"),
		        new ShipmentEntity(101, "Adam", "5987413568", Long.valueOf("8500000"), "New York")));
	}
}
