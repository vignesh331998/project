import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ShipmentJunit {
	
	ShipmentBO shipmentBO;
	double delta = 0.0;
	
	@Before
	public void setUp()
	{
		shipmentBO = new ShipmentBO();
	}
	
	@Test
	public void testLeftOutValue() {
	    double a[] = {1.0,2.0,3.0,4.0,5.0};
	    assertTrue(shipmentBO.findLeftOutValue(a) == 1.0);
	    double a1[] = {1,2,3,4,5,6};
	    assertTrue(shipmentBO.findLeftOutValue(a1) == 1.0);
	    double a2[] = {2.5,2.0,3.5,4.5,6.25,0.5,0.25,0.11,0.1,0.2,3.0,4.0,4.5};
	    assertTrue(shipmentBO.findLeftOutValue(a2) == 0.1);
	    double a3[] = {2.5,2.0,3.5,4.5,6.25,0.5,0.25,0.11,0.2,3.0,4.0,4.5,0.1};
	    assertTrue(shipmentBO.findLeftOutValue(a3) == 0.1);
		
	}
}
