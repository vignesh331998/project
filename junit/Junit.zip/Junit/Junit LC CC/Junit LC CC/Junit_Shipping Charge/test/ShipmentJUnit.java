import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	ShipmentBO shipmentBo;
	double delta = 0;

	@Before
	public void setup() {
		shipmentBo = new ShipmentBO();
	}

	@Test
	public void testEvaluateShippingCharge_forRoad() {
	    assertEquals(20.40, shipmentBo.evaluateShippingCharge(120, 450, "Road"), delta);
	    assertEquals(2.4, shipmentBo.evaluateShippingCharge(120, 0, "RoaD"), delta);
	    assertEquals(18.0, shipmentBo.evaluateShippingCharge(0, 450, "ROAD"), delta);
	}

	@Test
	public void testEvaluateShippingCharge_forSea() {
	    assertEquals(29.988, shipmentBo.evaluateShippingCharge(120, 450, "Sea"), delta);
	    assertEquals(2.448, shipmentBo.evaluateShippingCharge(120, 0, "SeA"), delta);
	    assertEquals(27.54, shipmentBo.evaluateShippingCharge(0, 450, "SEA"), delta);
	}

	@Test
	public void testEvaluateShippingCharge_forAir() {
	    assertEquals(347.4, shipmentBo.evaluateShippingCharge(120, 450, "Air"), delta);
	    assertEquals(302.4, shipmentBo.evaluateShippingCharge(120, 0, "AiR"), delta);
	    assertEquals(345.0, shipmentBo.evaluateShippingCharge(0, 450, "AIR"), delta);
	}
}
