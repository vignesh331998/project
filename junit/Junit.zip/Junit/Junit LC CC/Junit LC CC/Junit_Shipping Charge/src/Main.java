import java.util.Scanner;
class Main{
    public static void main(String args[]){
    	ShipmentBO shipmentBO = new ShipmentBO();
    	Scanner s=new Scanner(System.in);
        System.out.println("Enter the weight :");
        double weight=s.nextDouble();
        System.out.println("Enter the distance :");
        double distance=s.nextDouble();
        System.out.println("Enter the mode :");
        String mode=s.next();
        Double shippingCharge=0.0;
        
        
        shippingCharge=shipmentBO.evaluateShippingCharge(weight, distance, mode);
            System.out.println(shippingCharge);
        s.close();
    }
}