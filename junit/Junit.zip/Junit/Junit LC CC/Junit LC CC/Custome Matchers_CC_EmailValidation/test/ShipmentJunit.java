
import static org.hamcrest.MatcherAssert.assertThat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import org.junit.*;
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;


public class ShipmentJunit {
	
	ShipmentBO shipmentBO;
	
	@Before
	public void createObjectForEmailGenerator()
	{
		shipmentBO = new ShipmentBO();
	}
	
	@Test
	public void testEmailId() {
		
		SimpleDateFormat sdf  = new SimpleDateFormat("MM/dd/yyyy");
		try {
			Date date1 = sdf.parse("12/16/1991");			
			assertThat(shipmentBO.generateEmailId("John",date1),
				EmailIdChecker.chekemailid("john1991@gmail.com") );
			Date date2 = sdf.parse("10/13/2001");
			assertThat(shipmentBO.generateEmailId("Hari",date2),
			EmailIdChecker.chekemailid("hari2001@gmail.com") );
			Date date3 = sdf.parse("04/20/1986");
			assertThat(shipmentBO.generateEmailId("Raj",date3),
				EmailIdChecker.chekemailid("raj1986@gmail.com") );					
		
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
	class EmailIdChecker extends TypeSafeMatcher<String>{

		String emailid;
		
		public EmailIdChecker(String emailid)
		{
			this.emailid = emailid;
		}
		
		@Override
		public void describeTo(Description description) {
			description.appendText("Email ID is " + emailid);
		}

		@Override
		protected boolean matchesSafely(String item) {
			if (item.equals(emailid))
			return true;
			else 
			return false;
		}
		public static EmailIdChecker chekemailid(String emailid)
		{
			return new EmailIdChecker(emailid);
			
		}
	 
		
	}
