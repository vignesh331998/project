import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	
	ShipmentBO shipmentBO;
	
	@Before
	public void createObjectForShipmentBO() {
		shipmentBO = new ShipmentBO();
	}
	
	@Test
	public void testMsc() {
		assertEquals("Mediterranean Shipping Company",shipmentBO.getMinimalCost(1,2,3));
	    assertEquals("Mediterranean Shipping Company",shipmentBO.getMinimalCost(1,1,1));
	    assertEquals("Mediterranean Shipping Company",shipmentBO.getMinimalCost(1,2,1));
	    assertEquals("Mediterranean Shipping Company",shipmentBO.getMinimalCost(1,1,2));
	}
	
	@Test
	public void testCosco() {
	    assertEquals("China Ocean Shipping Company(COSCO)",shipmentBO.getMinimalCost(4,2,3));
	    assertEquals("China Ocean Shipping Company(COSCO)",shipmentBO.getMinimalCost(2,1,1));
	}
	
	@Test
	public void testEm() {
		assertEquals("Evergreen Marine",shipmentBO.getMinimalCost(4,2,1));
	}
}