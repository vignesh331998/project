

public class ShipmentBO {

	public Integer findShippedItemCount(Integer noofitems,Integer weight,Integer containerCapacity)
	{
		Integer totalWeight = noofitems * weight;
		return  (totalWeight > containerCapacity) ? (containerCapacity/weight) : noofitems; 
	}
	public Integer findLeftOutCount(Integer noofitems,Integer noOfShippedItems)
	{
		return noofitems - noOfShippedItems;
	}
}
