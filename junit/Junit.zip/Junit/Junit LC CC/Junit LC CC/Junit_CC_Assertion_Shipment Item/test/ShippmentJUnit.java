import static org.junit.Assert.*;

import org.junit.*;

public class ShippmentJUnit {

	ShipmentBO shipmentBO;
	
	@Before
	public void objectCeration()
	{
		shipmentBO = new ShipmentBO();
	}
	
	@Test
	public void testShippedItemCount()
	{
		assertEquals(Integer.valueOf(5), shipmentBO.findShippedItemCount(5, 10, 60));
		assertEquals(Integer.valueOf(10), shipmentBO.findShippedItemCount(10, 10, 100));
		assertEquals(Integer.valueOf(0), shipmentBO.findShippedItemCount(10, 100, 90));
	}
	@Test
	public void testLeftOutCount()
	{
		assertEquals(Integer.valueOf(4), shipmentBO.findLeftOutCount(9, 5));
		assertEquals(Integer.valueOf(0), shipmentBO.findLeftOutCount(5, 5));	
	}
	
	
}
