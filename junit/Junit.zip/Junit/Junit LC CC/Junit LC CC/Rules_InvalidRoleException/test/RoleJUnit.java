import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class RoleJUnit {
	RoleBO roleBO;
	@Before
	public void createObjectForRoleBO() {
		roleBO = new RoleBO();
	}
	@Test
	public void testIsRolePresent() throws InvalidRoleException {
	    User user = roleBO.isRolePresent(101,"Jones Smith",20);
	    assertEquals(user.getId(),101);
	    assertEquals(user.getName(),"Jones Smith");
	    assertEquals(user.getRole().getId(),20);
	}
	
	@Test
	public void testIsRolePresent_Exception() throws InvalidRoleException {
		   try {
		        roleBO.isRolePresent(101,"Jones Smith",50);
		        fail();
		    }
		    catch(InvalidRoleException e) {
		        assertEquals(e.toString(),"InvalidRoleException: Role id is invalid");
		    }
        
        
	}
}