import java.util.ArrayList;
import java.util.HashSet;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;

public class ShipmentJUnit {
	ShipmentBO shipmentBO;
	ArrayList<String> shipmentId;
		
	@Before
	public void createObjectForShipmentBO() {
		
		shipmentBO = new ShipmentBO();
		shipmentId = new ArrayList<>();
	}
	
	@Test
	public void testUniqueShipmentByCode() {
		shipmentId.add("BLUDR65");
		shipmentId.add("BLUDR90");
		shipmentId.add("BLUDR23");
		shipmentId.add("FLDR25");
	    HashSet<String> unique = shipmentBO.findShipmentByCode(shipmentId,"BLUDR");
	    assertThat(unique,containsInAnyOrder("BLUDR65","BLUDR23","BLUDR90"));
		
	
	}
}