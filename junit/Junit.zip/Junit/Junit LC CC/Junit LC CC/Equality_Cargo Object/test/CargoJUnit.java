import static org.junit.Assert.*;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CargoJUnit {
	Cargo cargo;
	CargoBO cargobo;
	@Before
	public void createObjectForCargo() {
		cargo = new CargoBO().cargoDetails("Cars","Lamborghini Veneno",300,225);
		
	}
	@Test
	public void testCargoDetails() {
		assertTrue(EqualsBuilder.reflectionEquals(new Cargo("Cars","Lamborghini Veneno",300,225),cargo));
	}
	@After
	public void teardown()
	{
		cargobo = null;
	}
	
}