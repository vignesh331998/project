import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class CustomerJunit {
	CustomerBO customerbo;
	
	@Before
	public void createObjectForCustomerBO(){
		customerbo = new CustomerBO();
		
	}
	
	@Test
	public void testValuableCustomer() {
	    assertEquals("Valuable customer",customerbo.findValuableCustomerOrNot(25));
	    assertEquals("Valuable customer",customerbo.findValuableCustomerOrNot(30));
	}
	
	@Test
	public void testNonValuableCustomer() {
	    assertEquals("Not a valuable customer",customerbo.findValuableCustomerOrNot(15));
	    assertEquals("Not a valuable customer",customerbo.findValuableCustomerOrNot(20));
	}
	
	@Test
	public void testInvalidShipment() {
	    assertEquals("Invalid Input",customerbo.findValuableCustomerOrNot(-1));
	    assertEquals("Invalid Input",customerbo.findValuableCustomerOrNot(0));
	}

}
