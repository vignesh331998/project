import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class ShipmentJUnit {
	
	ShipmentBO shipmentbo;
	
	@Before
	public void setUp()
	{
		shipmentbo = new ShipmentBO();
	}
	
	@Test
	public void testEvaluateGrade_invalidInput() {
		assertEquals("Invalid Input", shipmentbo.evaluateGrade(-1, -2));
		assertEquals("Invalid Input", shipmentbo.evaluateGrade(-2, 2));
		assertEquals("Invalid Input", shipmentbo.evaluateGrade(3, -3));
	}
	
	@Test
	public void testEvaluateGrade_gradeA() {
		assertEquals("A",shipmentbo.evaluateGrade(155, 1600));
		assertEquals("A",shipmentbo.evaluateGrade(180, 1700));
	}
	
	@Test
	public void testEvaluateGrade_gradeB() {
		assertEquals("B",shipmentbo.evaluateGrade(130, 1300));
		assertEquals("B",shipmentbo.evaluateGrade(150, 1500));
	}
	
	
	@Test
	public void testEvaluateGrade_gradeC() {
		assertEquals("C",shipmentbo.evaluateGrade(110, 1100));
		assertEquals("C",shipmentbo.evaluateGrade(125, 1200));
	}
	
	@Test
	public void testEvaluateGrade_gradeD() {
		assertEquals("D",shipmentbo.evaluateGrade(90, 800));
		assertEquals("D",shipmentbo.evaluateGrade(100, 1000));
	}
	
	@Test
	public void testEvaluateGrade_gradeE() {
		assertEquals("E",shipmentbo.evaluateGrade(65, 598));
		assertEquals("E",shipmentbo.evaluateGrade(75, 700));
	}
	
	
	
}
