
import static org.junit.Assert.*;

import org.junit.*;

public class ShipmentJunit {
	
	ShipmentBO shipmentbo;
	
	@Before
	public void createObjectForShipmentBO()
	{
		shipmentbo = new ShipmentBO();
	}
	@Test
	public void testfindNearestPort()
	{
		assertEquals(Integer.valueOf(-1),shipmentbo.findNearestPort(5,4));
		assertEquals(Integer.valueOf(1), shipmentbo.findNearestPort(1,2));
		assertEquals(Integer.valueOf(0), shipmentbo.findNearestPort(10,10));
		
	}
	
}
